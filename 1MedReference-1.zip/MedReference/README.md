# MedReference 2.0
**web/** – the website / installable PWA (host the folder on any HTTPS server; on Android Chrome use Menu > Install app). Works offline.
**android/** – native Android Studio project (WebView shell, fully offline, Android back button supported).

Build the app: open `android/` in Android Studio > let Gradle sync > Build > Build APK(s) (or Generate Signed Bundle for Play Store).
After editing `web/index.html`, copy it over `android/app/src/main/assets/index.html`.
Study aid only - not clinically validated; verify against local guidance.
