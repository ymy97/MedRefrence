package com.medreference.app;
import android.content.Intent;import android.net.Uri;import android.os.Bundle;import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;import androidx.webkit.WebViewAssetLoader;import androidx.webkit.WebViewClientCompat;
public class MainActivity extends AppCompatActivity{
 private WebView web;
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  web=new WebView(this);setContentView(web);
  final WebViewAssetLoader ld=new WebViewAssetLoader.Builder().addPathHandler("/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);
  web.setWebViewClient(new WebViewClientCompat(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return ld.shouldInterceptRequest(r.getUrl());}
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
    if("appassets.androidplatform.net".equals(r.getUrl().getHost()))return false;
    startActivity(new Intent(Intent.ACTION_VIEW,r.getUrl()));return true;}});
  web.loadUrl("https://appassets.androidplatform.net/index.html");}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}